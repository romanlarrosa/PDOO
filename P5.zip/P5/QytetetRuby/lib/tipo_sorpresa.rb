#encoding:utf-8
module ModeloQytetet
  module TipoSorpresa
    PAGARCOBRAR = :pagar_cobrar
    SALIRCARCEL = :salir_carcel
    PORCASAHOTEL= :por_casa_hotel
    PORJUGADOR = :por_jugador
    IRACASILLA = :ir_a_casilla
    CONVERTIRME = :convertirme
    
  end
end