# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module ModeloQytetet
  module EstadoJuego
    JA_CONSORPRESA = :ja_consorpresa
    ALGUNJUGADORENBANCARROTA = :algunjugadorenbancarrota
    JA_PUEDECOMPRAROGESTIONAR = :ja_puedecomprarogestionar
    JA_PUEDEGESTIONAR = :ja_puedegestionar
    JA_PREPARADO = :ja_preparado
    JA_ENCARCELADO = :ja_encarcelado
    JA_ENCARCELADOCONOPCIONDELIBERTAD = :ja_encarceladoconopciondelibertad
  end
end
